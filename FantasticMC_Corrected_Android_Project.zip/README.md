# FantasticMC Android project

This archive contains the Android Gradle project at its root, including the `app/` module and a GitHub Actions workflow.

## Build

The GitHub Actions workflow is `.github/workflows/build.yml`. After the project files are present at the repository root, open Actions and run **Build FantasticMC APK**. On success, download the `FantasticMC-debug-apk` artifact.

Application ID: `com.fanstatic.mc`
Version: `1.0`
Accent: `#467CD4`

Note: this is a companion UI prototype. HUD entries are demos and do not modify Minecraft gameplay. Floating overlay functionality requires Android overlay permission; Minecraft detection also requires Usage Access permission.
