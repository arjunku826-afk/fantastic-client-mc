# FantasticMC Android Project

A corrected, standard Android Gradle project for the FantasticMC companion UI prototype.

- Application ID: `com.fanstatic.mc`
- Version: `1.0`
- Accent color: `#467CD4`
- Build: GitHub Actions workflow at `.github/workflows/build.yml`

## Build with GitHub Actions

Push the contents of this project to the root of a GitHub repository, then open **Actions** and run **Build FantasticMC APK**. On success, download the `FantasticMC-debug-apk` artifact.

## Current limitations

This is a starter UI prototype, not a Minecraft mod or gameplay client. The floating logo depends on Android overlay permission and usage-access permission. HUD entries are UI demonstrations; they do not read live Minecraft game state or change gameplay. The floating logo is shown when Android usage stats identify Minecraft as the most recently used app.
