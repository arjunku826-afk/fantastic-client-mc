package com.fantastic.mc

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject

/**
 * Hosts the FantasticMC UI (assets/index.html) in a WebView and exposes a small,
 * honest bridge: detect Minecraft, ask Android to open it, and manage the floating logo.
 * It does NOT inject into or modify Minecraft.
 */
class MainActivity : Activity() {

    companion object {
        const val MC_PACKAGE = "com.mojang.minecraftpe"
    }

    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#07090d"))
        setContentView(web)
        hideSystemUi()

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true      // localStorage = persistent settings + HUD layout
            allowFileAccess = true
            allowContentAccess = false
            setSupportZoom(false)
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                // Keep the app on its own bundled page; never navigate away.
                return request.url.scheme != "file"
            }
        }
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
    }

    @Suppress("DEPRECATION")
    private fun hideSystemUi() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    override fun onResume() {
        super.onResume()
        // The floating logo can be closed from its own "x"; let the UI re-sync its toggle.
        web.evaluateJavascript("window.fmcSync&&window.fmcSync()", null)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.fmcBack?window.fmcBack():false)") { result ->
            if (result != "true") finish()
        }
    }

    override fun onDestroy() {
        web.removeJavascriptInterface("Android")
        web.destroy()
        super.onDestroy()
    }

    inner class Bridge {

        @JavascriptInterface
        fun getMinecraftInfo(): String {
            val o = JSONObject()
            try {
                @Suppress("DEPRECATION")
                val info = packageManager.getPackageInfo(MC_PACKAGE, 0)
                o.put("installed", true)
                o.put("version", info.versionName ?: "unknown")
            } catch (e: PackageManager.NameNotFoundException) {
                o.put("installed", false)
            }
            return o.toString()
        }

        @JavascriptInterface
        fun launchMinecraft(): String {
            val o = JSONObject()
            val intent = packageManager.getLaunchIntentForPackage(MC_PACKAGE)
            if (intent == null) {
                o.put("ok", false)
                o.put("msg", "Minecraft Bedrock Edition was not found on this device ($MC_PACKAGE).")
                return o.toString()
            }
            return try {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                runOnUiThread { startActivity(intent) }
                o.put("ok", true)
                o.put("msg", "Launch request sent to Android. FantasticMC cannot verify that the game opened.")
                o.toString()
            } catch (e: Exception) {
                o.put("ok", false)
                o.put("msg", "Android refused to open Minecraft: ${e.message}")
                o.toString()
            }
        }

        @JavascriptInterface
        fun openHudEditor() {
            runOnUiThread {
                startActivity(Intent(this@MainActivity, HudEditorActivity::class.java))
            }
        }

        @JavascriptInterface
        fun isFloating(): Boolean = FloatingService.running

        @JavascriptInterface
        fun setFloating(on: Boolean): String {
            val o = JSONObject()
            if (!on) {
                runOnUiThread { stopService(Intent(this@MainActivity, FloatingService::class.java)) }
                o.put("ok", true)
                o.put("msg", "Floating logo closed.")
                return o.toString()
            }
            if (!Settings.canDrawOverlays(this@MainActivity)) {
                runOnUiThread {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                }
                o.put("ok", false)
                o.put("msg", "Allow \"Display over other apps\" for FantasticMC, come back, then switch this on again.")
                return o.toString()
            }
            runOnUiThread { startService(Intent(this@MainActivity, FloatingService::class.java)) }
            o.put("ok", true)
            o.put("msg", "Floating logo shown. Tap it to open FantasticMC, tap x to close it.")
            return o.toString()
        }
    }
}
