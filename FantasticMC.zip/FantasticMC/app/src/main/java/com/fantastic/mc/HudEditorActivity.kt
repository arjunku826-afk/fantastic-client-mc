package com.fantastic.mc

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Native, full-screen FantasticMC HUD editor.
 * Drag HUD elements over a simulated Minecraft-style scene. Positions are saved automatically
 * on the phone. The background is a drawn preview, NOT live Minecraft gameplay.
 */
class HudEditorActivity : Activity() {

    private lateinit var editor: HudEditorView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hideSystemUi()

        val dp = resources.displayMetrics.density
        val accent = Color.parseColor("#467cd4")

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#07090d"))
        }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((12 * dp).toInt(), 0, (12 * dp).toInt(), 0)
            setBackgroundColor(Color.parseColor("#0d121a"))
        }

        val back = makeButton("← BACK", Color.parseColor("#111824"), Color.parseColor("#26354a"))
        back.setOnClickListener { finish() }

        val title = TextView(this).apply {
            text = "FantasticMC  HUD Editor"
            setTextColor(Color.WHITE)
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val reset = makeButton("RESET LAYOUT", accent, accent)

        bar.addView(back)
        bar.addView(title)
        bar.addView(reset)
        root.addView(bar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (46 * dp).toInt()))

        editor = HudEditorView(this)
        root.addView(editor, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val note = TextView(this).apply {
            text = "Drag elements to move them. Layout saves automatically. Simulated scene, not live Minecraft."
            setTextColor(Color.parseColor("#5f6c7f"))
            textSize = 10f
            gravity = Gravity.CENTER
            setPadding(0, (3 * dp).toInt(), 0, (4 * dp).toInt())
        }
        root.addView(note)

        reset.setOnClickListener { editor.resetLayout() }

        setContentView(root)
    }

    private fun makeButton(label: String, fill: Int, stroke: Int): Button {
        val dp = resources.displayMetrics.density
        return Button(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 11f
            isAllCaps = false
            typeface = Typeface.DEFAULT_BOLD
            minHeight = 0
            minimumHeight = 0
            setPadding((14 * dp).toInt(), 0, (14 * dp).toInt(), 0)
            background = GradientDrawable().apply {
                setColor(fill)
                setStroke((1 * dp).toInt().coerceAtLeast(1), stroke)
                cornerRadius = 7 * dp
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, (32 * dp).toInt()
            )
        }
    }

    @Suppress("DEPRECATION")
    private fun hideSystemUi() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }
}

/** One draggable HUD element. fx/fy = center position as a fraction (0..1) of the preview. */
internal class HudItem(val id: String, val defX: Float, val defY: Float, val kind: Int) {
    var fx = defX
    var fy = defY
    val rect = RectF()

    companion object {
        const val TEXT = 0
        const val KEYS = 1
        const val CROSSHAIR = 2
    }
}

internal class HudEditorView(context: Context) : View(context) {

    private val prefs = context.getSharedPreferences("fmc_hud_layout", Context.MODE_PRIVATE)
    private val accent = Color.parseColor("#467cd4")
    private val dp = resources.displayMetrics.density

    private val items = listOf(
        HudItem("fps", 0.09f, 0.06f, HudItem.TEXT),
        HudItem("clock", 0.50f, 0.06f, HudItem.TEXT),
        HudItem("cps", 0.91f, 0.06f, HudItem.TEXT),
        HudItem("coords", 0.16f, 0.14f, HudItem.TEXT),
        HudItem("potion", 0.90f, 0.16f, HudItem.TEXT),
        HudItem("keys", 0.09f, 0.82f, HudItem.KEYS),
        HudItem("armor", 0.88f, 0.92f, HudItem.TEXT),
        HudItem("cross", 0.50f, 0.50f, HudItem.CROSSHAIR),
        HudItem("nametag", 0.50f, 0.36f, HudItem.TEXT)
    )

    private val clicks = ArrayList<Long>()
    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

    // preview rectangle (16:9) inside this view
    private var pLeft = 0f
    private var pTop = 0f
    private var pW = 1f
    private var pH = 1f

    private var dragging: HudItem? = null
    private var offX = 0f
    private var offY = 0f

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        typeface = Typeface.DEFAULT_BOLD
    }
    private val gridPaint = Paint().apply {
        color = Color.argb(46, 255, 255, 255)
        strokeWidth = 1f
    }

    init {
        loadLayout()
    }

    private fun loadLayout() {
        items.forEach {
            it.fx = prefs.getFloat(it.id + "_x", it.defX)
            it.fy = prefs.getFloat(it.id + "_y", it.defY)
        }
    }

    private fun saveLayout() {
        val e = prefs.edit()
        items.forEach {
            e.putFloat(it.id + "_x", it.fx)
            e.putFloat(it.id + "_y", it.fy)
        }
        e.apply()
    }

    fun resetLayout() {
        items.forEach {
            it.fx = it.defX
            it.fy = it.defY
        }
        saveLayout()
        invalidate()
    }

    private fun computeBounds() {
        val w = width.toFloat()
        val h = height.toFloat()
        var pw = w - 16 * dp
        var ph = pw * 9f / 16f
        if (ph > h - 8 * dp) {
            ph = h - 8 * dp
            pw = ph * 16f / 9f
        }
        pW = pw.coerceAtLeast(1f)
        pH = ph.coerceAtLeast(1f)
        pLeft = (w - pW) / 2f
        pTop = (h - pH) / 2f
    }

    private fun cpsNow(): Int {
        val limit = System.currentTimeMillis() - 1000
        clicks.removeAll { it < limit }
        return clicks.size
    }

    private fun textFor(id: String): String = when (id) {
        "fps" -> "FPS: 120"
        "coords" -> "XYZ: 120, 64, -32"
        "cps" -> "CPS: ${cpsNow()}"
        "armor" -> "ARMOR ■■■■"
        "potion" -> "SPEED II"
        "clock" -> timeFormat.format(Date())
        "nametag" -> "[FMC] TheObfuscated"
        else -> ""
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        computeBounds()
        drawScene(canvas)
        drawGrid(canvas)

        val ts = pW * 0.024f
        textPaint.textSize = ts
        items.forEach { drawItem(canvas, it, ts) }

        stroke.color = accent
        stroke.strokeWidth = 1.5f * dp
        stroke.pathEffect = null
        canvas.drawRoundRect(RectF(pLeft, pTop, pLeft + pW, pTop + pH), 8 * dp, 8 * dp, stroke)

        // keep CPS / clock fresh
        postInvalidateDelayed(500)
    }

    private fun drawScene(c: Canvas) {
        val right = pLeft + pW
        val bottom = pTop + pH
        val horizon = pTop + pH * 0.57f

        fill.shader = LinearGradient(
            0f, pTop, 0f, horizon,
            Color.parseColor("#142941"), Color.parseColor("#24435a"), Shader.TileMode.CLAMP
        )
        c.drawRect(pLeft, pTop, right, horizon, fill)
        fill.shader = null

        fill.color = Color.parseColor("#263822")
        c.drawRect(pLeft, horizon, right, bottom, fill)
        fill.color = Color.parseColor("#426338")
        c.drawRect(pLeft, horizon, right, horizon + pH * 0.015f, fill)

        // sun
        fill.color = Color.argb(204, 255, 255, 255)
        c.drawCircle(pLeft + pW * 0.76f, pTop + pH * 0.22f, pW * 0.012f, fill)

        // blocks
        val b = pW * 0.044f
        fill.color = Color.parseColor("#596d44")
        stroke.color = Color.argb(77, 0, 0, 0)
        stroke.strokeWidth = 1f
        stroke.pathEffect = null
        listOf(0.18f to 0.50f, 0.225f to 0.50f, 0.74f to 0.47f, 0.785f to 0.47f).forEach { (bx, by) ->
            val r = RectF(pLeft + pW * bx, pTop + pH * by - b, pLeft + pW * bx + b, pTop + pH * by)
            c.drawRect(r, fill)
            c.drawRect(r, stroke)
        }

        // player
        val pw = pW * 0.028f
        val px = pLeft + pW * 0.5f - pw / 2
        val feet = pTop + pH * 0.71f
        fill.color = Color.parseColor("#4d70a7")
        c.drawRect(px, feet - pw * 2, px + pw, feet, fill)
        fill.color = Color.parseColor("#c89572")
        c.drawRect(px, feet - pw * 3, px + pw, feet - pw * 2, fill)
    }

    private fun drawGrid(c: Canvas) {
        val cols = 32
        val rows = 18
        for (i in 0..cols) {
            val x = pLeft + pW * i / cols
            c.drawLine(x, pTop, x, pTop + pH, gridPaint)
        }
        for (j in 0..rows) {
            val y = pTop + pH * j / rows
            c.drawLine(pLeft, y, pLeft + pW, y, gridPaint)
        }
    }

    private fun drawItem(c: Canvas, it: HudItem, ts: Float) {
        val cx = pLeft + pW * it.fx
        val cy = pTop + pH * it.fy
        val pad = ts * 0.6f
        val selected = it === dragging

        when (it.kind) {
            HudItem.TEXT -> {
                val label = textFor(it.id)
                val tw = textPaint.measureText(label)
                val w = tw + pad * 2
                val h = ts * 1.2f + pad * 2
                it.rect.set(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2)
                fill.color = Color.argb(160, 0, 0, 0)
                c.drawRoundRect(it.rect, ts * 0.4f, ts * 0.4f, fill)
                stroke.color = if (it.id == "nametag" || selected) accent else Color.argb(60, 255, 255, 255)
                stroke.strokeWidth = 1f * dp
                stroke.pathEffect = null
                c.drawRoundRect(it.rect, ts * 0.4f, ts * 0.4f, stroke)
                textPaint.color = Color.WHITE
                c.drawText(label, cx - tw / 2, cy + ts * 0.36f, textPaint)
            }
            HudItem.KEYS -> {
                val ks = ts * 1.9f
                val gap = ts * 0.25f
                val w = ks * 3 + gap * 2
                val h = ks * 2 + gap
                it.rect.set(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2)
                val keys = listOf(
                    "W" to (1 to 0), "A" to (0 to 1), "S" to (1 to 1), "D" to (2 to 1)
                )
                keys.forEach { (k, pos) ->
                    val l = it.rect.left + pos.first * (ks + gap)
                    val t = it.rect.top + pos.second * (ks + gap)
                    val r = RectF(l, t, l + ks, t + ks)
                    fill.color = Color.argb(160, 0, 0, 0)
                    c.drawRoundRect(r, ts * 0.3f, ts * 0.3f, fill)
                    stroke.color = Color.argb(90, 255, 255, 255)
                    stroke.strokeWidth = 1f * dp
                    stroke.pathEffect = null
                    c.drawRoundRect(r, ts * 0.3f, ts * 0.3f, stroke)
                    val kw = textPaint.measureText(k)
                    c.drawText(k, l + (ks - kw) / 2, t + ks / 2 + ts * 0.36f, textPaint)
                }
            }
            else -> { // crosshair
                val s = ts * 1.4f
                it.rect.set(cx - s, cy - s, cx + s, cy + s)
                stroke.color = Color.WHITE
                stroke.strokeWidth = 2f * dp
                stroke.pathEffect = null
                c.drawLine(cx - s, cy, cx + s, cy, stroke)
                c.drawLine(cx, cy - s, cx, cy + s, stroke)
            }
        }

        if (selected) {
            stroke.color = Color.WHITE
            stroke.strokeWidth = 1.5f * dp
            stroke.pathEffect = DashPathEffect(floatArrayOf(8f * dp, 5f * dp), 0f)
            val r = RectF(it.rect)
            r.inset(-4 * dp, -4 * dp)
            c.drawRect(r, stroke)
            stroke.pathEffect = null
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        computeBounds()
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                clicks.add(System.currentTimeMillis())
                val slop = 8 * dp
                dragging = items.lastOrNull {
                    val r = RectF(it.rect)
                    r.inset(-slop, -slop)
                    r.contains(e.x, e.y)
                }
                dragging?.let {
                    offX = e.x - (pLeft + pW * it.fx)
                    offY = e.y - (pTop + pH * it.fy)
                    parent?.requestDisallowInterceptTouchEvent(true)
                }
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                dragging?.let {
                    it.fx = ((e.x - offX - pLeft) / pW).coerceIn(0f, 1f)
                    it.fy = ((e.y - offY - pTop) / pH).coerceIn(0f, 1f)
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging != null) saveLayout()
                dragging = null
                invalidate()
                return true
            }
        }
        return super.onTouchEvent(e)
    }
}
