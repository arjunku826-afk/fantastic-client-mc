# FantasticMC v1.0

A dark-blue, landscape-style client companion app for Minecraft Bedrock Edition on Android.
Package: `com.fantastic.mc` · Native Android (Kotlin) shell + your UI in a WebView.

## Build the APK (no coding needed)

1. Create a new repository on GitHub and upload **everything** in this folder (keep the `.github` folder).
2. Open the **Actions** tab. The "Build APK" workflow runs automatically on every push
   (or press **Run workflow**).
3. When it finishes, open the run and download the **FantasticMC-debug-apk** artifact.
4. Unzip it, copy `app-debug.apk` to your phone and install it
   (allow "install unknown apps" when Android asks).

The APK is built at `app/build/outputs/apk/debug/app-debug.apk`.
If the build fails, the workflow turns red and the log shows the error.

## What each feature really does

| Feature | Status |
|---|---|
| Start screen, navigation, search, categories, favorites | Works inside the app |
| Module toggles | Saved; they change the in-app preview only |
| HUD editor | Native full-screen `HudEditorActivity` (drag elements, grid, Back, Reset Layout, auto-saved layout). The web editor with resize and visibility toggles remains as the fallback outside the Android app |
| Settings (accent, username, prefix, scale, grid, theme) | Saved on the phone |
| Launch Minecraft | Asks Android to open `com.mojang.minecraftpe`. The app cannot verify the game opened |
| Minecraft version info | Read from Android's package manager when installed |
| Floating logo | Standard "Display over other apps" overlay; tap = open FantasticMC, drag = move, x = close |

Module badges: **WORKING** = runs inside this app, **UI ONLY** = interface works but does
nothing to Minecraft, **PLANNED** = not built yet (toggle disabled).

## Limitations (please read)

- **FantasticMC does not inject into or modify Minecraft.** Bedrock on Android has no
  supported mod API, so modules cannot change gameplay. The HUD is a preview/editor only.
- **No live game capture.** Showing real Minecraft frames would need Android MediaProjection
  (a screen-recording permission and foreground service). It is not implemented, so the
  preview is a clearly labeled simulated scene.
- The floating logo is untested on real devices. Android 10+ restricts apps starting
  activities from the background; an app with a visible overlay is normally allowed.
- The UI is locked to landscape (Minecraft is landscape too), so there is no "rotate your phone" screen.
- Cheat-style modules from the first sketch (aim assist, ESP, tracers, hitboxes, velocity,
  step, air jump) were left out on purpose; they would get players banned on most servers.

## Not tested

This project was generated without an Android SDK, so it has **not** been compiled or run on a
device. Only the HTML/JavaScript syntax and XML files were checked. The GitHub Actions build
is the first real compile; send me the error log if it fails and I'll fix it.

## Files

- `app/src/main/assets/index.html` – the whole UI, module catalog, HUD editor, settings
- `app/src/main/java/com/fantastic/mc/MainActivity.kt` – WebView host and Android bridge
- `app/src/main/java/com/fantastic/mc/HudEditorActivity.kt` – native HUD editor
- `app/src/main/java/com/fantastic/mc/FloatingService.kt` – floating logo
- `app/src/main/AndroidManifest.xml`, `app/build.gradle`, `build.gradle`, `settings.gradle`
- `.github/workflows/build-apk.yml` – APK build
